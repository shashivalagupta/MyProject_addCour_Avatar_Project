import {combineReducers} from 'redux';

import CourseReducer from './CourseReducer';


const rootReducer=combineReducers(
   { CourseReducer }
);
export default rootReducer;