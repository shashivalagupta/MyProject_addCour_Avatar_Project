import React from 'react';
//import {Link} from 'react-router';
//import {connect} from "react-redux";
//import { Button, ButtonGroup, ButtonToolbar } from 'react-bootstrap-buttons';
// import "./aboutstyle.css";
class About extends React.Component{
    render(){
        return (
        <div>
            This is about page
        </div>
        );
    }
}
export default About;