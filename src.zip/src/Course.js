import React from 'react';
//import {Link} from 'react-router';
import {connect} from 'react-redux';
import  {CourseAction} from "./Action/CourseAction";
import { bindActionCreators } from 'redux';
import {get}from "lodash";
//import { Button, ButtonGroup, ButtonToolbar } from 'react-bootstrap-buttons';
// import "./aboutstyle.css";
class Course extends React.Component{
    constructor(props,context){
        super(props,context);
        this.state={
            course:{title:""}
        };
        this.onTittleChange=this.onTittleChange.bind(this);
        this.onClickSave=this.onClickSave.bind(this);
    }
   
    onTittleChange(event){
        const cs=this.state.course;
        cs.title=event.target.value;
        this.setState({course: cs})
    }
    onClickSave(){
        // this.props.dispatch(CourseAction.createCourse(this.state.course));
        this.props.actions.createCourse(this.state.course);
       
        // this.props.actions.resetCourse();
    }
    courseRow(course,index){
        return <div key={index}>{course.title}</div>;
    }
    
    render(){
        return (
        <div>
            <h1>Courses</h1>
           { console.log("this.props-->",this.props)}
            
             {/* {this.props.courses.map(this.courseRow)} */}
            <h2>Add Course</h2>
            <input type="text"
                onChange={this.onTittleChange}
                value={this.state.course.title}/>
            <input type="Submit"
                value="Save"
                onClick={this.onClickSave}/>
                {/* <button onClick={this.onClickSave()}>Save</button> */}

        <h3> {this.props.courses.courseTitle===undefined ?"":this.props.courses.courseTitle.title}</h3>  
        </div>
        );
    }

  
}
// Course.PropTypes={
//     dispatch:PropTypes.func.isRequired,
//     courses:PropTypes.array.isRequired
// };
function mapDispatchToProps(dispatch){
    return {actions:bindActionCreators({
        ...CourseAction
    },dispatch)};
};

const mapStateToProps=(state)=>({
    // return {
        // courses:get('state.CourseReducer.courseTitle.title',"")
        
        courses:state.CourseReducer
    // }
});
export default connect(mapStateToProps,mapDispatchToProps)(Course);